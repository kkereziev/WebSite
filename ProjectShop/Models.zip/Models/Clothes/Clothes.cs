﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectShop.Models.Clothes
{
    public abstract class Clothes 
    {
        public Guid Id { get; set; }
    }
}
